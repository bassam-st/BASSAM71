# إدارة المشاريع (مختصر عملي)
## WBS
- تقسيم المشروع إلى حزم عمل (Foundations, Frames, MEP, Finishes).

## الجدولة
- CPM: أنشطة + علاقات (FS/SS/FF) + حساب المسار الحرج.
- أدوات: Primavera/MS Project.

## التحكم في التكلفة — Earned Value
- PV: Planned Value
- EV: Earned Value
- AC: Actual Cost
- CPI = EV/AC (>1 جيد)،  SPI = EV/PV (>1 متقدم زمانيًا)
- EAC ≈ BAC / CPI

## إدارة المخاطر
- مصفوفة (احتمال × أثر)، خطط استجابة (تجنب/تقليل/نقل/قبول).
- سجل مخاطر محدث باستمرار.
