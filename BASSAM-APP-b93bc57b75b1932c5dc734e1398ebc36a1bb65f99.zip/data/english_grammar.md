# إنجليزي — قواعد سريعة
## الأزمنة الأساسية
- Present Simple: I work
- Present Continuous: I am working
- Past Simple: I worked
- Present Perfect: I have worked
- Future (will/going to): I will go / I am going to go

## نصائح كتابة
- جمل قصيرة وواضحة
- فعل قوي في البداية
- تجنب التكرار والحشو

## تصحيح شائع
- their / there / they're
- its / it's
- effect / affect
