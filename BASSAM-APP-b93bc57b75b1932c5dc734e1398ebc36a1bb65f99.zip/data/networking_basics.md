# شبكات
- طبقات OSI: Phys, DataLink, Network, Transport, Session, Presentation, Application
- IP: IPv4، IPv6 — قناع الشبكة يحدد الرينج
- TCP vs UDP: الاعتمادية مقابل السرعة
- أدوات تشخيص: ping, traceroute, nslookup, curl
- أمن: جدران نارية، VLAN، VPN، تحديثات مستمرة
